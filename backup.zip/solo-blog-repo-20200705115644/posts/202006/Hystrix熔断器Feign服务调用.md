title: Hystrix熔断器&Feign服务调用
date: '2020-06-23 10:54:56'
updated: '2020-06-23 11:05:21'
tags: [微服务, spring, springcloud]
permalink: /articles/2020/06/23/1592880896358.html
---
## Hystrix

- 问题场景：在高并发领域，在分布式系统中。可能因为大量的请求访问，导致一个小小的功能扛不住压力，宕机了。就可能造成其他连锁的服务也宕机。最终整个系统挂逼了。
- <font color='red'>Hystrix ： 熔断器。即系统的保险丝，为了避免在高并发下，一个小功能服务宕机了，而连锁反应造成其他服务也宕机。导致整个系统挂了，有效的保护了其他服务的正常运行。</font>

### Hystrix工作原理

![1544067870889.png](https://b3logfile.com/file/2020/06/1544067870889-f40ee35b.png)

- 当服务繁忙时，如果服务出现异常，不是粗暴的直接报错，而是返回一个友好的提示，虽然拒绝了用户的访问，但是会返回一个结果。

### 消费者端代码实现

1. 导入依赖：

   ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````
    <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-starter-netflix-hystrix</artifactId>
    </dependency>
   ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````
2. 开启熔断

   - 在启动类上添加注解

     ``````````````````````````````````````````````
       @EnableHystrix      //开启熔断器机制
     ``````````````````````````````````````````````
3. 在使用远程调用RestTemplate的方法上添加注解，并且添加一个错误信息返回的方法。

   ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````
    /**
     * 对当前方法，添加熔断机制的注解；如果触发熔断就会，调用queryUserByIdFallback方法
    * */
    @HystrixCommand(fallbackMethod = "queryUserByIdFallback")
    public User queryUserById(Long id){
        User user = this.restTemplate.getForObject("http://user-service/user/" + id, User.class);
        return user;
    }

    /**
     * @param id 对应熔断机制的方法的参数列表
     * @return 错误信息
     */
    public User queryUserByIdFallback(Long id){
        User user = new User();
        user.setId(id);
        user.setUserName("本方法为Hystrix熔断器方法，请求失败");
        return user;
    }
   ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````
4. 总结：

   1. `@HystrixCommand(fallbackMethod="queryUserByIdFallback")`：声明一个失败回滚处理函数queryUserByIdFallback，当queryUserById执行超时（默认是1000毫秒），就会执行fallback函数，返回错误提示。

### 优化熔断器

- 重试机制与熔断器的冲突：
  ![1544067870269.png](https://b3logfile.com/file/2020/06/1544067870269-9d50244f.png)
- 在yml中配置：

  ````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````
    hystrix:
      command:
      	default:
            execution:
              isolation:
                thread:
                  timeoutInMilliseconds: 6000 # 设置hystrix的超时时间为6000ms
  ````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````

---

## Feign

- <font color='red'>Feign: SpringCloud的远程服务调用技术。</font>
- Feign把Rest的请求进行隐藏，伪装成类似SpringMVC的controller一样，不用再自己拼接URL。一切交给Feign去做。

### 代码实现

1. 导入依赖

   ```xml
   <dependency>
   	<groupId>org.springframework.cloud</groupId>
   	<artifactId>spring-cloud-starter-openfeign</artifactId>
   </dependency>
   ```
2. 在启动类添加注解

   ``````````````````````````````````````````````````````````````````````
    ```
    @EnableFeignClients //开启 Feign远程调用组件技术
    ```
   ``````````````````````````````````````````````````````````````````````
3. 创建一个接口，作为Feign的客户端，与提供者连接请求。

   ``````````````
    @FeignClient("user-service")
    	public interface UserFeignClient {
    	/**
         * 该方法，的GetMapping与 user-service服务的请求地址 一致。
         */
        @GetMapping("/user/{id}")
        User queryUserById(@PathVariable("id") Long id);
    }
   ``````````````


   - 首先这是一个接口，Feign会通过动态代理，帮我们生成实现类。
   - `@FeignClient`，声明这是一个Feign客户端，类似 `@Mapper`注解。同时通过 `value`属性指定服务名称
   - 接口中的定义方法，完全采用SpringMVC的注解，Feign会根据注解帮我们生成URL，并访问获取结果
4. 修改消费者中，请求的代码

   ```````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````
    @Autowired
    private UserFeign userFeign;

    /**
     * 对当前方法，添加熔断机制的注解；如果触发熔断就会，调用queryUserByIdFallback方法
    * */
    public User queryUserById(Long id){
        User user = userFeign.queryById(id);
        //使用负载均衡器方式，请求
        return user;
    }
   ```````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````

### Feign总结

- Feign自动集成了Ribbon负载均衡，因此我们不需要设置Ribbon了。
- Hystrix熔断器支持：
  1. 默认是关闭的，yml配置打开

     ````````````````````````````````````````````````````````````````````
      feign:
        hystrix:
          enabled: true # 开启Feign的熔断功能
     ````````````````````````````````````````````````````````````````````
  2. 定义一个类，实现自定义的 FeignClient的客户端接口，作为fallback处理类

     ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````
      @Component
      public class UserFeignClientFallback implements UserFeign {
          @Override
          public User queryById(Long id) {
              User user = new User();
              user.setId(id);
              user.setName("用户查询出现异常！");
              return user;
          }
      }
     ``````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````
  3. 在UserFeign客户端中，指定fallback类：

     `````````````````````````````````````````````````````
      //添加容器机制的 feign
      @FeignClient(value = "user-service" , fallback = UserFeignClientFallback.class)
      public interface UserFeign {
          /**
           * 该方法，的GetMapping与 user-service服务的请求地址 一致。
           */
          @GetMapping("/user/{id}")
          public User queryById(@PathVariable("id") Long id);
      }
     `````````````````````````````````````````````````````
  4. 使用Feign远程调用，如果触发了熔断器，就会返回UserFeignClientFallback类信息。
     <br/>
     <br/>
- 如果使用了Feign远程调用，那么就不用再单独配置Ribbon和Hystrix，只需要在Feign上配置。
