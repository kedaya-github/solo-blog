title: cloud-config拆分配置yml&cloud-bus消息总线
date: '2020-06-23 10:54:57'
updated: '2020-06-23 18:34:30'
tags: [java, springcloud, 微服务, spring]
permalink: /articles/2020/06/23/1592880897001.html
---
![](https://b3logfile.com/bing/20191124.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## springcloud-config统一配置文件yml

- 分布式系统中，由于服务数量众多。为了方便统一管理yml配置文件。
- 使用springcloud-config进行远程yml配置文件的管理。
- 将服务中的yml配置文件抽取出来，放到Git服务器中。每次请求服务时，服务会先去git服务器中，拉取自己需要的yml配置文件。
- 详细内容看在线文档： https://springcloud.cc/spring-cloud-config.html
- 图解释说明：

  ![](M:\学习套路2==\MD笔记\互联吗技术\assets\2.png)

## springcloud-bus消息总线

- 如果我们更新了码云git服务器中的yml配置文件后。服务也会进行更新。
- 比如user服务开始配置的服务器是A地址，我在码云仓库中修改成B地址，那么user服务就能重新编译。更新数据库地址。不要重启服务。
- 对运维工作很友好。

## 配置服务端

- 创建一个服务，作为 config的服务端。进行git拉取服务
- 不需要注册到eureka中心
- 结合了config 和 bus
- pom依赖：

  ```pom
          <!-- TODO config服务器 -->
          <dependency>
              <groupId>org.springframework.cloud</groupId>
              <artifactId>spring-cloud-config-server</artifactId>
          </dependency>
          <!-- TODO bus消息总线组件-->
          <dependency>
              <groupId>org.springframework.cloud</groupId>
              <artifactId>spring-cloud-bus</artifactId>
          </dependency>
          <!-- TODO RabbitMQ配合bus一起使用，进行yml文件的更新-->
          <dependency>
              <groupId>org.springframework.cloud</groupId>
              <artifactId>spring-cloud-stream-binder-rabbit</artifactId>
          </dependency>
  ```
- 添加application启动类注解：

  ```java
  @SpringBootApplication
  @EnableConfigServer //开启springcloud-config配置文件服务
  public class ConfigApplication {
      public static void main(String[] args) {
          SpringApplication.run(ConfigApplication.class , args);
          System.out.println("config启动");
      }
  }
  ```
- application.yml配置文件

  ```yml
  spring:
    application:
      name: tensquare-config
    cloud:
      config:
        server:
          git:
            uri: https://gitee.com/wxl888/tensquare-config.git # git服务器地址
    rabbitmq: # bus消息总线配置
      host: 127.0.0.1 # RabbitMQ的地址 地址默认 15672

  server:
   port: 12000

  # bus消息总线配置
  management: #暴露触发消息总线的地址
    endpoints:
      web:
        exposure:
          include: bus-refresh # 进行触发RabbitMQ 更新yml 的消息地址
  ```

## 客户端

- 具体服务进行yml拉取。
- pom依赖：

  ```
          <!-- TODO config配置文件服务客户端 -->
          <dependency>
              <groupId>org.springframework.cloud</groupId>
              <artifactId>spring-cloud-config-client</artifactId>
          </dependency>
          <!-- TODO bus消息总线组件-->
          <dependency>
              <groupId>org.springframework.cloud</groupId>
              <artifactId>spring-cloud-bus</artifactId>
          </dependency>
          <!-- TODO RabbitMQ配合bus一起使用，进行yml文件的更新-->
          <dependency>
              <groupId>org.springframework.cloud</groupId>
              <artifactId>spring-cloud-stream-binder-rabbit</artifactId>
          </dependency>
          <!-- TODO bus总线的客户端，进行mq消息的消费。按钮 -->
          <dependency>
              <groupId>org.springframework.boot</groupId>
              <artifactId>spring-boot-starter-actuator</artifactId>
          </dependency>
  ```
- bootstrap.yml配置文件（删除掉application.yml配置文件）：

  ```yml
  spring:
    cloud:
      config: # 具体的yml拉取名称，根据码云仓库而定
        name: user  # - 号前面的名称
        profile: dev # - 号后面面的名称
        label: master  # 是master主节点
        uri: http://127.0.0.1:12000  # config服务的地址
    rabbitmq:
      host: 127.0.0.1
  ```
- controller添加注解：
- 当yml配置中使用了自定义信息，比如 jwt.config.key 这样的。就需要在使用了信息的controller上添加：

  ```java
  @RefreshScope  //表示可以使用yml自定义信息
  ```

## 修改了码云中yml文件后，要进行消息的传递

- bus消息总线是依赖与RabbitMQ的消息发送的。
- 当我们修改了 码云中yml文件信息后，要通过RabbitMQ发送让服务重新编译的消息命令。
- 使用postman调用此url。使用post请求

  ```
  http://127.0.0.1:12000/actuator/bus-refresh
  ```
