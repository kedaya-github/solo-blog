title: 使用maven搭建SpringCloud项目
date: '2020-06-23 10:55:00'
updated: '2020-06-23 18:42:33'
tags: [Note, 微服务, java, springcloud]
permalink: /articles/2020/06/23/1592880900731.html
---
![](https://b3logfile.com/bing/20180805.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 使用maven搭建SpringCloud项目

### 创建maven父项目：

![img](assets/245245.png)

- 书写项目包名，和项目名称（项目名不能使用横杠"-"，只能使用下划线 _ 区分）

![img](assets/432432423.png)

#### maven父项目加入 可能使用的所有依赖

```xml
	<parent>
		<groupId>org.springframework.boot</groupId>
		<artifactId>spring-boot-starter-parent</artifactId>
		<version>2.2.2.RELEASE</version>
		<relativePath/> <!-- lookup parent from repository -->
	</parent>

    <!-- TODO 总体的版本配置 -->
    <properties>
    	<project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    	<project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>
    	<java.version>1.8</java.version>
    	<spring-cloud.version>Hoxton.RELEASE</spring-cloud.version>
    	<mybatis.starter.version>1.3.2</mybatis.starter.version>
    	<mapper.starter.version>2.1.3</mapper.starter.version>
    	<druid.starter.version>1.1.9</druid.starter.version>
    	<mysql.version>5.1.32</mysql.version>
    	<pageHelper.starter.version>1.2.3</pageHelper.starter.version>
    	<jjwt.version>0.7.0</jjwt.version>
    	<joda-time.version>2.9.6</joda-time.version>
    </properties>

    <!-- TODO   dependencyManagement规定父模块，以及其子模块的版本，规定的jar包，子项目引入依赖时，不用再指定版本号 -->
    <dependencyManagement>
    	<dependencies>
    		<!-- springCloud -->
    		<dependency>
    			<groupId>org.springframework.cloud</groupId>
    			<artifactId>spring-cloud-dependencies</artifactId>
    			<version>${spring-cloud.version}</version>
    			<type>pom</type>
    			<scope>import</scope>
    		</dependency>
    		<!-- mybatis启动器 -->
    		<dependency>
    			<groupId>org.mybatis.spring.boot</groupId>
    			<artifactId>mybatis-spring-boot-starter</artifactId>
    			<version>${mybatis.starter.version}</version>
    		</dependency>
    		<!-- 通用Mapper启动器 -->
    		<dependency>
    			<groupId>tk.mybatis</groupId>
    			<artifactId>mapper-spring-boot-starter</artifactId>
    			<version>${mapper.starter.version}</version>
    		</dependency>
    		<dependency>
    			<groupId>com.github.pagehelper</groupId>
    			<artifactId>pagehelper-spring-boot-starter</artifactId>
    			<version>${pageHelper.starter.version}</version>
    		</dependency>
    		<!-- druid启动器 -->
    		<dependency>
    			<groupId>com.alibaba</groupId>
    			<artifactId>druid-spring-boot-starter</artifactId>
    			<version>${druid.starter.version}</version>
    		</dependency>
    		<dependency>
    			<groupId>mysql</groupId>
    			<artifactId>mysql-connector-java</artifactId>
    			<version>${mysql.version}</version>
    		</dependency>
    		<dependency>
    			<groupId>io.jsonwebtoken</groupId>
    			<artifactId>jjwt</artifactId>
    			<version>${jjwt.version}</version>
    		</dependency>
    		<!-- https://mvnrepository.com/artifact/joda-time/joda-time -->
    		<dependency>
    			<groupId>joda-time</groupId>
    			<artifactId>joda-time</artifactId>
    			<version>${joda-time.version}</version>
    		</dependency>
    	</dependencies>
    </dependencyManagement>

	<!-- TODO 项目依赖 -->
	<dependencies>
		<!-- TODO springboot启动器 -->
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter</artifactId>
		</dependency>

		<!--TODO web项目的所有jar包 包含spring ， springmvc ， springboot-->
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-web</artifactId>
		</dependency>

		<!-- TODO mybatis支持-->
		<dependency>
			<groupId>org.mybatis.spring.boot</groupId>
			<artifactId>mybatis-spring-boot-starter</artifactId>
		</dependency>

		<!--TODO 通用mapper启动器 -->
		<dependency>
			<groupId>tk.mybatis</groupId>
			<artifactId>mapper-spring-boot-starter</artifactId>
		</dependency>

		<!-- TODO 分页的启动器 -->
		<dependency>
			<groupId>com.github.pagehelper</groupId>
			<artifactId>pagehelper-spring-boot-starter</artifactId>
		</dependency>

		<!--TODO 数据库连接池启动器-->
		<dependency>
			<groupId>com.alibaba</groupId>
			<artifactId>druid-spring-boot-starter</artifactId>
		</dependency>

		<!-- TODO mysql驱动 -->
		<dependency>
			<groupId>mysql</groupId>
			<artifactId>mysql-connector-java</artifactId>
		</dependency>

		<!--TODO jdbc 启动器 -->
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-jdbc</artifactId>
		</dependency>

		<!-- TODO eureka客户端 和 Feign远程调用 -->
		<dependency>
			<groupId>org.springframework.cloud</groupId>
			<artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
		</dependency>
		<dependency>
			<groupId>org.springframework.cloud</groupId>
			<artifactId>spring-cloud-starter-openfeign</artifactId>
		</dependency>

		<!-- TODO 重试机制 -->
		<dependency>
			<groupId>org.springframework.retry</groupId>
			<artifactId>spring-retry</artifactId>
		</dependency>

		<!-- TODO jwt鉴权依赖 -->
		<dependency>
			<groupId>io.jsonwebtoken</groupId>
			<artifactId>jjwt</artifactId>
		</dependency>
		<!-- https://mvnrepository.com/artifact/joda-time/joda-time -->
		<dependency>
			<groupId>joda-time</groupId>
			<artifactId>joda-time</artifactId>
		</dependency>

		<!-- TODO SpringCloud的Zuul网关 -->
		<dependency>
			<groupId>org.springframework.cloud</groupId>
			<artifactId>spring-cloud-starter-netflix-zuul</artifactId>
		</dependency>

		<!-- TODO SpringCloud的Eureka服务端 -->
		<dependency>
			<groupId>org.springframework.cloud</groupId>
			<artifactId>spring-cloud-starter-netflix-eureka-server</artifactId>
		</dependency>
	</dependencies>

    <!-- TODO 配置spring的私服，增加下载速度 -->
    <repositories>
    	<repository>
    		<id>spring-milestones</id>
    		<name>Spring Milestones</name>
    		<url>https://repo.spring.io/milestone</url>
    		<snapshots>
    			<enabled>false</enabled>
    		</snapshots>
    	</repository>
    </repositories>
```

#### 创建 common和pojo 共享模块，将 JwtUtls 和 BaseResult 和 数据库表对应的实体类 等...共享类写在其中，其他服务模块引入

---

### 在当前 父项目上直接搭建 子模块服务，使用maven方式

#### 加入共享模块的依赖（如果不需要依赖别的模块可以不加）

```xml
    <dependencies>
        <!-- TODO 共享模块 -->
        <dependency>
            <groupId>com.czxy</groupId>
            <artifactId>cz_common</artifactId>
            <version>1.0-SNAPSHOT</version>
        </dependency>
        <dependency>
            <groupId>com.czxy</groupId>
            <artifactId>cz_pojo</artifactId>
            <version>1.0-SNAPSHOT</version>
        </dependency>

    </dependencies>
```

#### 编写启动类（一定要加上com.czxy的包！！！）

```java
public class ***Application {
    public static void main(String[] args) {
        SpringApplication.run(***Application.class , args);
        System.out.println("***模块服务启动");
    }
}
```

### <font color='red'>注意三点

1. 父子模块项目的 父子关系依赖，会自动依赖。不用管
2. 子模块项目中 不用再导入依赖，因为父模块中已经依赖完毕了。
3. 创建的maven项目，没有启动类和配置文件。需要手动编写，并且要加入com.czxy的包
4. 每次子模块服务中，yml配置文件，都必须指定 数据库连接</font>

```yml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/cloud_2019-12-19
    username: root
    password: root
    driverClassName: com.mysql.jdbc.Driver
```
