title: java爬虫CSDN博客
date: '2020-10-08 18:58:25'
updated: '2020-10-08 18:58:25'
tags: [spring, 爬虫]
permalink: /articles/2020/10/08/1602154705576.html
---
![](https://b3logfile.com/bing/20200628.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# java爬CSDN博客

* maven依赖：
  ```
  <!-- TODO java爬取csdn文章 -->
          <dependency>
              <!-- jsoup HTML parser library @ http://jsoup.org/ -->
              <groupId>org.jsoup</groupId>
              <artifactId>jsoup</artifactId>
              <version>1.9.2</version>
          </dependency>
          <dependency>
              <groupId>org.apache.httpcomponents</groupId>
              <artifactId>httpclient</artifactId>
              <version>4.5.1</version>
          </dependency>
          <dependency>
              <groupId>org.mockito</groupId>
              <artifactId>mockito-all</artifactId>
              <version>1.8.4</version>
          </dependency>
          <dependency>
              <groupId>junit</groupId>
              <artifactId>junit</artifactId>
              <version>4.12</version>
          </dependency>
  ```
* 代码：
  ```
  package com.csdn;

  import org.jsoup.Connection;
  import org.jsoup.Jsoup;
  import org.jsoup.nodes.Document;
  import org.jsoup.nodes.Element;
  import org.jsoup.select.Elements;

  import java.io.IOException;
  import java.util.ArrayList;
  import java.util.List;

  /**
   * @author 遗憾就遗憾吧
   * @Date 2020/5/6
   * @jdk 1.8
   */
  public class Test {

      private static final String URL = "http://blog.csdn.net/guolin_blog";

      //所有的文章
      private static List<ArticleEntity> resultList = new ArrayList<ArticleEntity>();

      public static void main(String[] args) throws IOException {
          //TODO 下面为设置 代理。因为有些公司可能是内网，设置代理才能访问外网，就需要下面的配置
  //        System.setProperty("http.maxRedirects", "50");
  //        System.getProperties().setProperty("proxySet", "true");
  //        // 如果不设置，只要代理IP和代理端口正确,此项不设置也可以
  //        String ip = "http://go.microsoft.com/fwlink/?LinkId=625115";
  //        System.getProperties().setProperty("http.proxyHost", ip);
  //        System.getProperties().setProperty("http.proxyPort", "8080");

          //调用 文章解析方法，进行文章的解析 映射成 pojo类
          goPage();
          System.out.println(resultList.size());
          System.out.println(resultList);
      }

      /**
       *  TODO despt:分页算法
       * @return
       * @throws IOException
       */
      public static void goPage() throws IOException{
          Connection conn = Jsoup.connect(URL)
                  //userAgent 代表你是什么浏览器访问的网站，不设置可能导致无法访问，每个浏览器的userAgent不一样
                  .userAgent("Mozilla/5.0 (Windows NT 6.1; rv:47.0) Gecko/20100101 Firefox/47.")
                  .timeout(30000)
                  .method(Connection.Method.GET);
          Document doc = conn.get();
          Element body = doc.body();

          //文章总数量
          String listTotal = body.getElementsByTag("script").toString().split("listTotal = ", 3)[1].split(" ;")[0];

          //获取总页数 ， 计算出总页数
          //每页默认是 40 个文章。
          int nums = Integer.parseInt(listTotal) / 40;
          //判断是否有 余数。
          nums = Integer.parseInt(listTotal) % 40 > 0 ? nums+1 : nums;

          System.out.println("总页数：" + nums);

          //进行 一个用户下所有文章的 查询
          for (int i = 1; i <= nums; i++) {
              //调用 每一个的爬虫数据分析 方法
              getArtitcleByPage(i);
          }
      }

      //TODO 进行每一页的 爬虫数据分析
      public static List<ArticleEntity> getArtitcleByPage(int pageNow) throws IOException{

          Connection conn = Jsoup.connect(URL + "/article/list/" + pageNow)
                  .userAgent("Mozilla/5.0 (Windows NT 6.1; rv:47.0) Gecko/20100101 Firefox/47.")
                  .timeout(30000)
                  .method(Connection.Method.GET);

          Document doc = conn.get();
          Element body = doc.body();


          Elements articleListDiv = body.getElementsByClass("article-list");
          Elements articleList = articleListDiv.get(0).getElementsByClass("article-item-box");
          for(Element article : articleList){
              ArticleEntity articleEntity = new ArticleEntity();

  //            System.out.println(article.select("h4 a").get(0).text());
              //TODO article.select 可以通过 层间的关系，获取到子级标签 , 通过attr可以获取属性的值， text可以获取文本值
              Element linkNode = (article.select("h4 a")).get(0);

              Element desptionNode = (article.getElementsByClass("content")).get(0);
              Element articleManageNode = (article.getElementsByClass("date")).get(0);

              articleEntity.setAddress(linkNode.attr("href"));
              articleEntity.setTitle(linkNode.text().substring(3));
              articleEntity.setDesption(desptionNode.text());
              articleEntity.setTime(articleManageNode.text());

              resultList.add(articleEntity);
          }
          return resultList;
      }
  }

  ```
* ArticleEntity的 pojo类：
  ```
  package com.csdn;

  /**
   * @author admin
   * TODO 此pojo可以直接与 数据库表进行映射。 做一个定时任务，每天固定时间去 csdn爬取文章
   */
  public class ArticleEntity {

      //文章地址
      private String address;

      //文章标题
      private String title;

      //文章简略的 描述内容
      private String desption;

      //文章发布时间
      private String time;

      //历史观看文书


      public String getAddress() {
          return address;
      }

      public void setAddress(String address) {
          this.address = address;
      }

      public String getTitle() {
          return title;
      }

      public void setTitle(String title) {
          this.title = title;
      }

      public String getDesption() {
          return desption;
      }

      public void setDesption(String desption) {
          this.desption = desption;
      }

      public String getTime() {
          return time;
      }

      public void setTime(String time) {
          this.time = time;
      }

      @Override
      public String toString() {
          return "ArticleEntity{" +
                  "address='" + address + '\'' +
                  ", title='" + title + '\'' +
                  ", desption='" + desption + '\'' +
                  ", time='" + time + '\'' +
                  '}';
      }
  }
  ```

# 整合springboot和Quartz定时爬虫

* 可以定义一个 url 爬虫地址数组。通过定时任务，来对这些 爬虫地址，进行一一的爬取，并且添加到 数据库中。
* 通过发布时间的判断，来避免 数据的重复添加。
* 项目地址：M:\大大大平台项目\csdn\myCSDN
* pom依赖：
  ```
  <!-- TODO java爬取csdn文章 -->
          <dependency>
              <!-- jsoup HTML parser library @ http://jsoup.org/ -->
              <groupId>org.jsoup</groupId>
              <artifactId>jsoup</artifactId>
              <version>1.9.2</version>
          </dependency>
          <dependency>
              <groupId>org.apache.httpcomponents</groupId>
              <artifactId>httpclient</artifactId>
              <version>4.5.1</version>
          </dependency>
          <dependency>
              <groupId>org.mockito</groupId>
              <artifactId>mockito-all</artifactId>
              <version>1.8.4</version>
          </dependency>
          <dependency>
              <groupId>junit</groupId>
              <artifactId>junit</artifactId>
              <version>4.12</version>
          </dependency>

          <!-- TODO springboot中的quartz -->
          <dependency>
              <groupId>org.springframework.boot</groupId>
              <artifactId>spring-boot-starter-quartz</artifactId>
          </dependency>
  ```
* QuartzConfig 配置类：
  ```
  @Configuration
  public class QuartzConfig {
      @Bean
      public JobDetail QuartzJobDetail(){
          return JobBuilder.newJob(MyJob.class)
                  .withIdentity("job1","group1")
                  .storeDurably()
                  .requestRecovery(true)
                  .build();
      }

      @Bean
      public Trigger QuartzTrigger(){
          return TriggerBuilder.newTrigger()
                  .withIdentity("tirgger1","group1")
                  .startNow()
                  .forJob(QuartzJobDetail()) //使用forjob 指定需要嵌套指定的jobDetail
                  //.withSchedule(SimpleScheduleBuilder.simpleSchedule().repeatSecondlyForever(5).repeatForever())
                  .withSchedule(CronScheduleBuilder.cronSchedule("1 14 * * * ?")) //使用日历方式 每小时的2分1秒开始执行
                  .build();
      }
  }
  ```
* myCSDN 爬虫任务类：
  ```
  //quartz的 任务job类
  @Component
  @Transactional
  public class MyJob extends QuartzJobBean{

      private static String URL = "http://blog.csdn.net/guolin_blog";

      //所有的文章
      private static List<ArticleEntity> resultList = new ArrayList<ArticleEntity>();

      @Autowired
      private ArticleMapper articleMapper;

      //TODO Quartz定时调用方法
      @Override
      protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
          String[] urls = new String[]{"http://blog.csdn.net/guolin_blog" , "http://blog.csdn.net/zhang5476499" , "http://blog.csdn.net/qq_42426159"};

          for (String url : urls) {
              URL = url;

              System.out.println("爬虫的地址："+URL);

              //实行爬虫任务
              //调用 文章解析方法，进行文章的解析 映射成 pojo类
              try {
                  goPage();
              } catch (Exception e) {
                  e.printStackTrace();
              }
              //进行 文章的插入
              System.out.println(resultList.size());
              System.out.println(resultList);

              for (ArticleEntity articleEntity : resultList) {
                  articleEntity.setId(String.valueOf(new IdWorker().nextId()));
                  articleMapper.insert(articleEntity);
              }
          }
          //进行 resultList的清空
          System.out.println("爬虫完毕");
      }

      /**
       *  TODO despt:分页算法
       * @return
       * @throws IOException
       */
      public void goPage() throws IOException, ParseException {
          Connection conn = Jsoup.connect(URL)
                  //userAgent 代表你是什么浏览器访问的网站，不设置可能导致无法访问，每个浏览器的userAgent不一样
                  .userAgent("Mozilla/5.0 (Windows NT 6.1; rv:47.0) Gecko/20100101 Firefox/47.")
                  .timeout(30000)
                  .method(Connection.Method.GET);
          Document doc = conn.get();
          Element body = doc.body();

          //文章总数量
          String listTotal = body.getElementsByTag("script").toString().split("listTotal = ", 3)[1].split(" ;")[0];

          //获取总页数 ， 计算出总页数
          //每页默认是 40 个文章。
          int nums = Integer.parseInt(listTotal) / 40;
          //判断是否有 余数。
          nums = Integer.parseInt(listTotal) % 40 > 0 ? nums+1 : nums;

          System.out.println("总页数：" + nums);
          //进行 resultList的清空
          resultList.clear();

          //进行 一个用户下所有文章的 查询
          for (int i = 1; i <= nums; i++) {
              //调用 每一个的爬虫数据分析 方法
              getArtitcleByPage(i);
          }
      }

      //TODO 进行每一页的 爬虫数据分析
      public List<ArticleEntity> getArtitcleByPage(int pageNow) throws IOException, ParseException {

          Connection conn = Jsoup.connect(URL + "/article/list/" + pageNow)
                  .userAgent("Mozilla/5.0 (Windows NT 6.1; rv:47.0) Gecko/20100101 Firefox/47.")
                  .timeout(30000)
                  .method(Connection.Method.GET);

          Document doc = conn.get();
          Element body = doc.body();


          Elements articleListDiv = body.getElementsByClass("article-list");
          Elements articleList = articleListDiv.get(0).getElementsByClass("article-item-box");
          for(Element article : articleList){
              ArticleEntity articleEntity = new ArticleEntity();

  //            System.out.println(article.select("h4 a").get(0).text());
              //TODO article.select 可以通过 层间的关系，获取到子级标签 , 通过attr可以获取属性的值， text可以获取文本值
              Element linkNode = (article.select("h4 a")).get(0);

              Element desptionNode = (article.getElementsByClass("content")).get(0);
              Element articleManageNode = (article.getElementsByClass("date")).get(0);
              //获取名称
              Element articleName = body.getElementsByClass("name").get(0);

              //通过当前的名称获取，在数据库中， 最新的文章日期  maxTime==null说明当前name用户 没有文章
              Date maxTime = articleMapper.findMaxTimeByName(articleName.text());
              if (maxTime != null && new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(articleManageNode.text()).getTime() <= maxTime.getTime()){
                  //跳转下一个 循环
                  continue;
              }

              articleEntity.setAddress(linkNode.attr("href"));
              articleEntity.setTitle(linkNode.text().substring(3));
              articleEntity.setDesption(desptionNode.text());
              articleEntity.setTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(articleManageNode.text()));
              articleEntity.setName(articleName.text());

              resultList.add(articleEntity);
          }
          return resultList;
      }
  }
  ```
