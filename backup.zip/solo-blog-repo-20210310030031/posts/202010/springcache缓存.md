title: spring-cache缓存
date: '2020-10-08 18:51:55'
updated: '2020-10-08 18:54:09'
tags: [Note, spring, java]
permalink: /articles/2020/10/08/1602154315303.html
---
# spring-cache缓存

- 以前的缓存技术 一般书写在代码中，代码耦合性太强。
- Spring中使用@Cacheable 和@CacheEvict实现缓存在某种程度上解决了耦合性问题，基本思想是在方法加上@Cacheable注解，这个方法的返回值将具有缓存特性。
- 与redis的区别：
  - redis有声明周期
- 一般使用中也会和 redis 进行整合使用，用上redis的声明周期
- 不适用场景：
  - 变化性较频繁的数据，如果使用当前缓存则会导致数据展示不是最新。造成数据错乱
- 使用场景：
  - 跟redis结合，然后作为 分布式锁，进行防重提交
  - 缓存变化不频繁的数据，列如: 每日排行榜信息 ， 首页固定栏目信息。

## 前言

- 一个大佬写的二级缓存文章，较为深入的解释了各种cache接口作用：
- [二级缓存](https://my.oschina.net/dengfuwei/blog/1616221?p=2)
- [spring cache接口](https://blog.csdn.net/zhouping118/article/details/106635557?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522160100390919724835823771%2522%252C%2522scm%2522%253A%252220140713.130102334.pc%255Fall.%2522%257D&request_id=160100390919724835823771&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~first_rank_v2~rank_v28-1-106635557.pc_first_rank_v2_rank_v28&utm_term=AbstractValueAdaptingCache%E6%9C%89%E4%BB%80%E4%B9%88%E5%8C%BA&spm=1018.2118.3001.4187)
- spring - cache 中有spring制定的 一些标准化接口，给各个 具体缓存框架(Redis,Caffnine,EhCache...) 等提供实现方法。可以使用 cache 的@cacheable...等缓存注解就可以使用缓存。而不需要在写一堆代码。

## 基本使用

- @EnableCaching

  ```
  完成一些简单的缓存操作 - 加载Application启动类上
  一般用于不会改动的数据上。如果数据容易改变，那么可能查的数据是之前缓存的，而造成数据不一致错误
  ```
- ```
  在类上使用，统一制定 类下面所有方法的 value 缓存组
  ```
- @Cacheable

  ```
  进行缓存 , 可以用在方法（返回值被缓存） 或 类上（所有方法缓存），
  下次使用相同方法和相同参数都会直接从缓存中查去，不会再走方法
  常用属性：
  value： 设置一个组 ， 即各个方法通过value组来进行共同缓存。必填
  key： 设置一个组件标识，用于区分同组下的不同缓存，不填系统默认生成，SpEL表达式
  condition： 条件判断，可以填写SpEL表达式，进行条件判断，是否去查询缓存
  sync：是否异步，默认为false
  keyGenerator： key的生成器，key/keyGenerator二选一使用。可以自定义key生成方法
  cacheManager： 指定使用哪个CacheManager
  ```

  ```
  key的一些设置案例：
  比如有一个方法是带分页查询的，那么我们的缓存key可以是 page + size 字符串拼起来
  @Cacheable(value = "page_user",key ="T(String).valueOf(#page).concat('-').concat(#pageSize)",unless = "#result=null")
  //由于page是int型,concat要求变量必须为String,所以强转一下
  @Override
  public List<SysUserEntity> page(int page, int pageSize) {
      return userMapper.page(page,pageSize);
  }
  ```

  ```java
  KeyGenerator的规则：
  1.如果方法只有一个参数，这个参数就是Key。
  2.如果没有参数，则Key是SimpleKey.EMPTY。
  3.如果有多个Key，则返回包含多个参数的SimpleKey。
  Spring使用SimpleKeyGenerator来实现上述key的生成。

  自定义key生成规则方法，需要实现 KeyGenerator 接口

  源码：
  package org.springframework.cache.interceptor;

  import java.lang.reflect.Method;

  public class SimpleKeyGenerator implements KeyGenerator {
      public SimpleKeyGenerator() {
      }

      public Object generate(Object target, Method method, Object... params) {
          return generateKey(params);
      }

      public static Object generateKey(Object... params) {
          if (params.length == 0) {
              return SimpleKey.EMPTY;
          } else {
              if (params.length == 1) {
                  Object param = params[0];
                  if (param != null && !param.getClass().isArray()) {
                      return param;
                  }
              }

              return new SimpleKey(params);
          }
      }
  }
  ```
- @CachePut

  ```
  操作后缓存，一般用在Post，put方法中。方法一定会去执行，执行后返回的数据会进行缓存
  三大属性与@cacheable基本一致
  ```
- @CacheEvict

  ```
  @CacheEvict是用来标注在需要清除缓存元素的方法或类上的
  常用属性：
  value： 设置一个组 ， 即各个方法通过value组来进行共同缓存。必填
  key： 设置一个组件标识，用于区分同组下的不同缓存，不填系统默认生成
  condition： 条件判断，可以填写SpEL表达式，进行条件判断
  allEntries： boolean类型，表示是否需要清除缓存中所有的元素，默认为false
  beforeInvocation： 方法前后执行清除，默认为false在方法执行之后进行清除，
  ```

### 流程

- 当执行到一个被@Cacheable注解的方法时，Spring首先检查condition条件是否满足，如果不满足，执行方法，返回；如果满足，在value所命名的缓存空间中查找使用key存储的对象，如果找到，将找到的结果返回，如果没有找到执行方法，将方法的返回值以key-对象的方式存入value缓存中，然后方法返回。
- 代码流程：
- dao操作数据库

  ```java
  写一个dao方法，模拟查询数据库

  @Component
  public class UserDao2 {

      private static Map<String, User> map = new HashMap<String,User>();

  	// init初始化数据加载
      @PostConstruct
      public static void run() {
          map.put("1",new User("1","123"));
          map.put("2",new User("2","456"));
      }

      @Cacheable(value = "user",key = "#id",condition = "#id == '1'")
      public User getUser(String id) {
          System.out.println("查询数据库111111-----------");
          return map.get(id);
      }

      @Cacheable(value = "user",key = "#id")
      public User getUser2(String id) {
          System.out.println("查询数据库22222-----------");
          return map.get(id);
      }

      @CachePut(value = "user",key = "#user.id")
      public void set(User user) {
          System.out.println("数据库操作3333333-----------");
          map.put(user.getId(),user);
      }

  }
  ```
- 调用缓存

  ```
  @RunWith(SpringJUnit4ClassRunner.class)
  @SpringBootTest(classes = {com.XXX.MyBoot.class})
  public class Test {

      @Autowired
      private UserDao2 userDao;

      @org.junit.Test
      public void run(){
          // 测试cacheable 各个方法之间的缓存

          //--同数据，同方法
          User user1 = userDao.getUser("1");
          System.out.println(user1);
          User user11 = userDao.getUser("1");
          System.out.println(user11);

          // 同数据，不同方法
          User user2 = userDao.getUser("2");
          System.out.println(user2);

          User user22 = userDao.getUser2("2");
          System.out.println(user22);
      }

      @org.junit.Test
      public void run2(){
          // 修改数据，并且缓存，在另一条方法中查询
          userDao.set(new User("3","789"));

          // 在其他进行查询，看是否缓存了
          System.out.println(userDao.getUser("3"));
      }

      @org.junit.Test
      public void run3(){
          // 测试condition 条件处理 , 只缓存处理 id == 1

          //--同数据，同方法
          User user1 = userDao.getUser("1");
          System.out.println(user1);
          User user11 = userDao.getUser("1");
          System.out.println(user11);

          // 同数据，不同方法
          User user2 = userDao.getUser("2");
          System.out.println(user2);
          User user22 = userDao.getUser("2");
          System.out.println(user22);
      }

  }
  ```

### 注意点

```
我们想找到两个不同的人，但是两个人的surname是相同的，你将发现两次调用返回了相同的结果，这不是Spring的问题，而是我们的cache key的生成方式有问题。所以在我们定义key的时候要小心注意key的生成策略，避免造成这种问题。
```

- key的生成策略
  1. 使用 #p参数idnex 来代表第几位参数： #p0 则代表第一位参数
  2. 一个root对象来生成key
  3. ![1600683558067](assets/1600683558067.png)

## 工作流程

- 工作原理： 就是使用了spring-aop 切面增强思想，在调用方法前，先走一遍缓存的查询方法，来查看是否有缓存
- 当你在配置类(@Configuration)上使用@EnableCaching注解时，会触发一个post processor，这会扫描每一个spring bean，查看是否已经存在注解对应的缓存。如果找到了，就会自动创建一个代理拦截方法调用，使用缓存的bean执行处理。
- 结构图：

  ![1601004059648.png](https://b3logfile.com/file/2020/10/1601004059648-35b6284c.png)

# Redis简单结合

- 对于分布式应用，通常都会将缓存放在一台或者多台专门的缓存服务器上。使用Redis作为缓存是一种常用的选择
- cache没有声明周期
- cache 的config配置类中@Bean返回一个实例时，可以返回 RedisCacheManager 来定义一个redis实现的 缓存实例。
- RedisCacheManager  和 ConcurrentMapCacheManager(cache simple默认) 共同继承同一个父类接口 CacheManager
- 通过application的配置文件, spring.cache.type=Redis  就可以设置cache使用Redisache进行缓存

### 实现方案

- 实现一个configuration配置类，来进行cache的替换成redis的配置
- config配置文件

  ```java
  @Configuration
  @ConditionalOnWebApplication
  public class CacheConfig {
      @Bean
      public RedisCacheManager cacheManager(RedisConnectionFactory redisConnectionFactory) {
          return new RedisCacheManager(
                  RedisCacheWriter.nonLockingRedisCacheWriter(redisConnectionFactory),
                  this.getRedisCacheConfigurationWithTtl( 60), // 默认过期时间，如果key没有单独配置就会使用这个60S
                  this.getRedisCacheConfigurationMap() // 指定 key 策略
          );
      }

      private Map<String, RedisCacheConfiguration> getRedisCacheConfigurationMap() {
          Map<String, RedisCacheConfiguration> redisCacheConfigurationMap = new HashMap<>();

          // 进行过期时间配置， 配置单独的 key 。 不同的key可以设置不同的过期时间
          redisCacheConfigurationMap.put("messagCache", this.getRedisCacheConfigurationWithTtl(30 * 60));

          //自定义设置缓存时间
          redisCacheConfigurationMap.put("user", this.getRedisCacheConfigurationWithTtl(60 ));

          return redisCacheConfigurationMap;
      }

      // 配置 key 的声明周期 过期时间
      private RedisCacheConfiguration getRedisCacheConfigurationWithTtl(Integer seconds) {
          Jackson2JsonRedisSerializer<Object> jackson2JsonRedisSerializer = new Jackson2JsonRedisSerializer<>(Object.class);
          ObjectMapper om = new ObjectMapper();
          om.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
          om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
          jackson2JsonRedisSerializer.setObjectMapper(om);
          RedisCacheConfiguration redisCacheConfiguration = RedisCacheConfiguration.defaultCacheConfig();
          redisCacheConfiguration = redisCacheConfiguration.serializeValuesWith( // serializeValuesWith设置存储的信息不乱吗
                  RedisSerializationContext
                          .SerializationPair
                          .fromSerializer(jackson2JsonRedisSerializer)
          ).entryTtl(Duration.ofSeconds(seconds));// Duration. 的方法可以设置 声明周期存活时间的单位，秒..分..

          return redisCacheConfiguration;
      }
  }
  ```
- application.properties配置文件

  ```xml
  # 配置redis参数
  spring.redis.port=6379
  spring.redis.database=0
  spring.redis.host=localhost
  spring.redis.timeout=600s
  spring.session.store-type=redis
  spring.cache.type=redis


  #---------------
  spring.cache.type 声明 spring的cache类型
  Simple：基于ConcurrentHashMap实现缓存，只适合单体应用
  None： 禁止使用缓存
  Redis： 使用Redis缓存
  ```
- UserDao - 模仿具体操作数据库接口

  ```java
  @Component
  public class UserDao {

      private static Map<String, User> map = new HashMap<String,User>();

      @PostConstruct
      public static void run() {
          map.put("1",new User("1","123"));
          map.put("2",new User("2","456"));
      }

      @Cacheable(value = "user",key = "#id")
      public User getUser(String id) {
          System.out.println("查询数据库111111-----------");
          return map.get(id);
      }

      @Cacheable(value = "user",key = "#id")
      public User getUser2(String id) {
          System.out.println("查询数据库22222-----------");
          return map.get(id);
      }

      @CachePut(value = "user",key = "#user.id")
      public void set(User user) {
          System.out.println("数据库操作3333333-----------");
          map.put(user.getId(),user);
      }

  }
  ```
- 调用测试

  ```java
  @RunWith(SpringJUnit4ClassRunner.class)
  @SpringBootTest(classes = {com.test.Boot.class})
  public class Test {
      @Autowired
      private UserDao userDao;

      @Autowired
      private RedisCacheManager redisCacheManager;

      @org.junit.Test
      public void run() {
          System.out.println("第一次：" + userDao.getUser("1"));
          System.out.println("第二次：" + userDao.getUser("1"));

          // 查询redisCache 中是否拥有缓存
          Cache cache = redisCacheManager.getCache("1");
          System.out.println(cache.getName());

          User user = cache.get(cache.getName(), User.class);
          System.out.println(user);
      }

      @org.junit.Test
      public void run2() {
      }

      @org.junit.Test
      public void run3() {
          System.out.println("第三次：" + userDao.getUser("1"));
      }
  }
  ```

# Ehcache

- EhCache是一个纯java的进程内缓存框架，具有快速，精干等特点。
- Ehcache是一种广泛使用的开源java分布式缓存，主要面向通用缓存，java EE和轻量级容器。具有内存和磁盘存储，缓存加载器，缓存扩展等特点

### 优点

- 快速，简单，拥有多种缓存策略
- 缓存数据有两级，内存和磁盘。无需担心容量不足
- 缓存数据会在JVM虚拟机重启时 将写入到磁盘，重启完毕在取出来
- 具有缓存和缓存管理器的侦听接口 。支持多缓存管理器实例，以及一个实例的多个缓存区域 等。

### 缺点

- 使用Cache时非常占用磁盘空间，因为DIskCache的算法简单，效率非常高。
- 不能保证数据的安全性。Ehcache是绑定在JVM虚拟机中，当突然kill掉java进程时，数据可能会有问题

### 和redis比较

- ehcache直接在jvm虚拟机中缓存，速度快，效率高；但是缓存共享麻烦，集群分布式应用不方便。
- redis是通过socket访问到缓存服务，效率比ecache低，比数据库要快很多，处理集群和分布式缓存方便，有成熟的方案。
- 如果是单个应用或者对缓存访问要求很高的应用，用ehcache。如果是大型系统，存在缓存共享、分布式部署、缓存内容很大的，建议用redis。
- <font color='red'> ehcache 对分布式支持不够好，多个节点不能同步，通常和redis一块使用 </font>

### EhCache2.X 使用

- pom依赖

  ```xml
  <!-- JSR107 API -->
   <dependency>
       <groupId>net.sf.ehcache</groupId>
       <artifactId>ehcache</artifactId>
       <version>2.10.6</version>
   </dependency>

  <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-cache</artifactId>
  </dependency>
  ```
- application配置文件

  ```yml
  spring:
   cache:
     type: ehcache
     ehcache:
       config: classpath:/cache/ehcache.xml // 需要写一个ehcache的xml配置文件
  ```
- ehcache.xml

  ```xml
  <ehcache>
      <!--
          磁盘存储:将缓存中暂时不使用的对象,转移到硬盘,类似于Windows系统的虚拟内存
          path:指定在硬盘上存储对象的路径
          path可以配置的目录有：
              user.home（用户的家目录）
              user.dir（用户当前的工作目录）
              java.io.tmpdir（默认的临时目录）
              ehcache.disk.store.dir（ehcache的配置目录）
              绝对路径（如：d:\\ehcache）
          查看路径方法：String tmpDir = System.getProperty("java.io.tmpdir");
       -->
      <diskStore path="java.io.tmpdir" />
      <!--
          defaultCache:默认的缓存配置信息,如果不加特殊说明,则所有对象按照此配置项处理
          maxElementsInMemory:设置了缓存的上限,最多存储多少个记录对象
          eternal:代表对象是否永不过期 (指定true则下面两项配置需为0无限期)
          timeToIdleSeconds:最大的发呆时间 /秒
          timeToLiveSeconds:最大的存活时间 /秒
          overflowToDisk:是否允许对象被写入到磁盘
          说明：下列配置自缓存建立起600秒(10分钟)有效 。
          在有效的600秒(10分钟)内，如果连续120秒(2分钟)未访问缓存，则缓存失效。
          就算有访问，也只会存活600秒。
       -->
      <defaultCache maxElementsInMemory="10000" eternal="false"
                    timeToIdleSeconds="600" timeToLiveSeconds="600" overflowToDisk="true" />
      <!-- cache就是具体的 缓存组。这里声明，然后@cacheable才可以使用 -->
      <cache name="myCache" maxElementsInMemory="10000" eternal="false"
                    timeToIdleSeconds="120" timeToLiveSeconds="600" overflowToDisk="true" />
  </ehcache>

  ```
- 使用的时候 `@CacheConfig(cacheNames = {"myuser"})`中的 `cacheNames`的名字，xml中的alias必须也有，不然会报找不到缓存名。

# 多缓存共存

- 我们可以在一个系统中存在多个缓存，而不使用二级缓存
- 比如： 存在Ehcache + redis 两个缓存。redis来存一些需要分布式共享数据，而Ehcache来存取一些单独的不易改变的数据。两个相互切换着 配合使用

### spring cache核心接口

- spring cache 主要有 两大 标准接口 Cache和CacheManager
- spring cache的实现是使用spring aop中对方法切面（MethodInterceptor）封装的扩展，当然spring aop也是基于Aspect来实现的。

#### Cache接口

- 提供缓存的具体操作：缓存写入，读取，清理。。等操作
- 子接口

  ![1600856563704.png](https://b3logfile.com/file/2020/10/1600856563704-78db4f82.png)
- Cache接口方法的操作：

  ```java
  #Cache.java

  package org.springframework.cache;

  import java.util.concurrent.Callable;

  public interface Cache {

  	// cacheName，缓存的名字，默认实现中一般是CacheManager创建Cache的bean时传入cacheName
  	String getName();

  	// 获取实际使用的缓存，如：RedisTemplate、com.github.benmanes.caffeine.cache.Cache<Object, Object>。暂时没发现实际用处，可能只是提供获取原生缓存的bean，以便需要扩展一些缓存操作或统计之类的东西
  	Object getNativeCache();

  	// 通过key获取缓存值，注意返回的是ValueWrapper，为了兼容存储空值的情况，将返回值包装了一层，通过get方法获取实际值
  	ValueWrapper get(Object key);

  	// 通过key获取缓存值，返回的是实际值，即方法的返回值类型
  	<T> T get(Object key, Class<T> type);

  	// 通过key获取缓存值，可以使用valueLoader.call()来调使用@Cacheable注解的方法。当@Cacheable注解的sync属性配置为true时使用此方法。因此方法内需要保证回源到数据库的同步性。避免在缓存失效时大量请求回源到数据库
  	<T> T get(Object key, Callable<T> valueLoader);

  	// 将@Cacheable注解方法返回的数据放入缓存中
  	void put(Object key, Object value);

  	// 当缓存中不存在key时才放入缓存。返回值是当key存在时原有的数据
  	ValueWrapper putIfAbsent(Object key, Object value);

  	// 删除缓存
  	void evict(Object key);

  	// 删除缓存中的所有数据。需要注意的是，具体实现中只删除使用@Cacheable注解缓存的所有数据，不要影响应用内的其他缓存
  	void clear();

  	// 缓存返回值的包装
  	interface ValueWrapper {

  		// 返回实际缓存的对象
  		Object get();
  	}

  	// 当{@link #get(Object, Callable)}抛出异常时，会包装成此异常抛出
  	@SuppressWarnings("serial")
  	class ValueRetrievalException extends RuntimeException {

  		private final Object key;

  		public ValueRetrievalException(Object key, Callable<?> loader, Throwable ex) {
  			super(String.format("Value for key '%s' could not be loaded using '%s'", key, loader), ex);
  			this.key = key;
  		}

  		public Object getKey() {
  			return this.key;
  		}
  	}
  }
  ```

#### CacheManager接口

- 主要提供Cache实现bean的创建

```java
#CacheManager.java

package org.springframework.cache;

import java.util.Collection;

public interface CacheManager {

	// 通过cacheName创建Cache的实现bean，具体实现中需要存储已创建的Cache实现bean，避免重复创建，也避免内存缓存对象（如Caffeine）重新创建后原来缓存内容丢失的情况
	Cache getCache(String name);

	// 返回所有的cacheName
	Collection<String> getCacheNames();
}
```

### pom文件

- redis的 实现类 redisCachemanager 依赖在 spring-boot-tarter-data-redis中
- 其他的缓存 Ehcache ， caffeine .. 的实现类CacheManager等都是在 spring-contxt-support中

  ```xml
  <dependency>
              <groupId>org.springframework.boot</groupId>
              <artifactId>spring-boot-starter-data-redis</artifactId>
          </dependency>
          <!-- ehcache 缓存 -->
          <dependency>
              <groupId>net.sf.ehcache</groupId>
              <artifactId>ehcache</artifactId>
              <version>2.10.6</version>
          </dependency>
          <!-- https://mvnrepository.com/artifact/org.springframework.session/spring-session-data-redis -->
          <dependency>
              <groupId>org.springframework.session</groupId>
              <artifactId>spring-session-data-redis</artifactId>
              <version>2.2.2.RELEASE</version>
          </dependency>
          <!-- https://mvnrepository.com/artifact/redis.clients/jedis -->
          <dependency>
              <groupId>redis.clients</groupId>
              <artifactId>jedis</artifactId>
              <version>3.2.0</version>
          </dependency>

  		<dependency>
  			<groupId>org.springframework</groupId>
  			<artifactId>spring-context-support</artifactId>
  			<version>5.2.3.RELEASE</version>
  		</dependency>
  ```

### 切换缓存

- 根据之前的内容配置后 redis 和 Ehcache
- 在Config文件中，加入 Ehcache 的 manager管理

  ```java
  @Configuration
  @ConditionalOnWebApplication
  public class CacheConfig {
      @Bean
      public RedisCacheManager cacheManager(RedisConnectionFactory redisConnectionFactory) {
          return new RedisCacheManager(
                  RedisCacheWriter.nonLockingRedisCacheWriter(redisConnectionFactory),
                  this.getRedisCacheConfigurationWithTtl( 60), // 默认过期时间，如果key没有单独配置就会使用这个60S
                  this.getRedisCacheConfigurationMap() // 指定 key 策略
          );
      }

      @Bean
      @Primary // 使用@Primary来指定 主 缓存。 
      // RedisCacheManager和EhCacheCacheManager都是实现CacheManager接口，需要指定一个默认的缓存
      public EhCacheCacheManager ehcache() {
          // 创建并返回 EhCacheCacheManager 的管理Bean
          return new EhCacheCacheManager(EhCacheManagerUtils.buildCacheManager());
      }

      .............
          ............
  }
  ```
- 切换缓存

  ```
  其他的使用还是一致的
  在@Cacheable() 中 通过属性 cacheManager 来指定使用哪一个缓存。 默认会使用加了@Primary的CacheManager
  ```

# Ehcache+Redis一二级缓存

- spring boot中集成了 spring cache，并有多种缓存的实现如：redis，Ehcache，Caffeine等
- 但如果只用一种缓存，可能会造成方方面面的问题。比如：
- 要么只用redis，就会有比较大的网络消耗，因为redis是独立服务
- 要么只用EhCache..Caffnine，这种内存缓存就会，缓存数据量不大，另外不利于分布式

### 分布式二级缓存

- 缓存：缓存就是将读取慢的媒介上的数据给拿出来放到 读取速度快的媒介上。比如 磁盘 -> 内存上。
- redis会占用网络消耗，而EhCache等则会占用内存消耗，并且只适用于小数据，小项目
- 二级缓存的实现：为了将两者的特性结合起来，组成一二级缓存
  - 适用EhCache + redis 进行二级缓存
  - 访问缓存数据时，先访问一级缓存EhCache，去JVM虚拟机缓存中找对应数据。当前属于是本地缓存，速度快。
  - 一级本地缓存没有，就通过网络连接去 redis 服务中查找数据，如果有就返回数据，并且更新一级缓存数据
  - 如果二级缓存redis中也没有，就去数据库中查找数据，并且更新 一级 + 二级 缓存。

    ![1600855328781.png](https://b3logfile.com/file/2020/10/1600855328781-ddfeb601.png)
- 从图中可以感受到，为了这个一二级缓存，可能要写非常多的代码。应用到业务代码中，而这就有了很多的耦合操作。拒绝
- spring cache 是 spring-context包下提供注解使用缓存的组件。定义了一些标准接口，通过实现接口，就可以通过在方法上加@cacheable等注解使用缓存。

### 实现过程

- 一般项目应用都是部署多个节点，集群/分布式，一级缓存是应用内的缓存，所以当数据清除时要通知所有节点进行清理缓存的操作。可以使用 zookeper ， MQ 等方法
- 用了redis做二级缓存，那么就可以使用redis自身的 订阅/发布 功能。不需要在依赖其他中间件。直接使用redis的通知来对节点进行清缓存操作。
- 本二级缓存略微简单，只是用了Ehcache + Redis的分布式缓存，用RediscacheCanmanager来作为 主 缓存存储。每次 put 缓存时，都发通知，清除分布式各个JVM上的一级Ehcache缓存。

#### 导入pom

- 导入pom依赖

  ```xml
  <dependencies>
      	<!-- TODO springboot项目启动器 -->
      	<dependency>
      		<groupId>org.springframework.boot</groupId>
      		<artifactId>spring-boot-starter</artifactId>
      	</dependency>

      	<dependency>
      		<groupId>org.springframework.boot</groupId>
      		<artifactId>spring-boot-starter-test</artifactId>
      	</dependency>

      	<!--TODO web项目的所有jar包 包含spring ， springmvc ， springboot-->
      	<dependency>
      		<groupId>org.springframework.boot</groupId>
      		<artifactId>spring-boot-starter-web</artifactId>
      	</dependency>

      	<!-- TODO mybatis支持-->
      	<dependency>
      		<groupId>org.mybatis.spring.boot</groupId>
      		<artifactId>mybatis-spring-boot-starter</artifactId>
      		<version>1.3.2</version>
      	</dependency>

      	<!--TODO 数据库连接池启动器-->
      	<dependency>
      		<groupId>com.alibaba</groupId>
      		<artifactId>druid-spring-boot-starter</artifactId>
      	</dependency>

      	<!-- TODO mysql驱动 -->
      	<dependency>
      		<groupId>mysql</groupId>
      		<artifactId>mysql-connector-java</artifactId>
      	</dependency>

      	<!--TODO jdbc 启动器 -->
      	<dependency>
      		<groupId>org.springframework.boot</groupId>
      		<artifactId>spring-boot-starter-jdbc</artifactId>
      	</dependency>

  		<!-- TODO 第三方redis缓存模块。 目的为了将第三方模块的bean注册到spring中 -->


          <dependency>
              <groupId>org.springframework.boot</groupId>
              <artifactId>spring-boot-starter-data-redis</artifactId>
          </dependency>
          <!-- ehcache 缓存 -->
          <dependency>
              <groupId>net.sf.ehcache</groupId>
              <artifactId>ehcache</artifactId>
              <version>2.10.6</version>
          </dependency>
          <!-- https://mvnrepository.com/artifact/org.springframework.session/spring-session-data-redis -->
          <dependency>
              <groupId>org.springframework.session</groupId>
              <artifactId>spring-session-data-redis</artifactId>
              <version>2.2.2.RELEASE</version>
          </dependency>
          <!-- https://mvnrepository.com/artifact/redis.clients/jedis -->
          <dependency>
              <groupId>redis.clients</groupId>
              <artifactId>jedis</artifactId>
              <version>3.2.0</version>
          </dependency>
          <!-- https://mvnrepository.com/artifact/p6spy/p6spy -->
          <dependency>
              <groupId>p6spy</groupId>
              <artifactId>p6spy</artifactId>
              <version>3.8.7</version>
          </dependency>

  		<dependency>
  			<groupId>org.springframework</groupId>
  			<artifactId>spring-context-support</artifactId>
  			<version>5.2.3.RELEASE</version>
  		</dependency>

      	<dependency>
  			<groupId>com.baomidou</groupId>
  			<artifactId>dynamic-datasource-spring-boot-starter</artifactId>
  			<version>3.0.0</version>
  		</dependency>

  		<dependency>
  			<groupId>com.alibaba</groupId>
  			<artifactId>fastjson</artifactId>
  			<version>1.2.68</version>
  		</dependency>
      </dependencies>
  ```

#### 编写application.properties

```properties
#spring.mvc.view.prefix=/WEB-INF/
#spring.mvc.view.suffix=.jsp
server.port=8080
# 可省略，SpringBoot自动推断
spring.datasource.druid.initial-size=5
spring.datasource.druid.min-idle=5
spring.datasource.druid.max-active=20
spring.datasource.druid.max-wait=60000
spring.datasource.druid.time-between-eviction-runs-millis=60000
spring.datasource.druid.min-evictable-idle-time-millis=300000
spring.datasource.druid.validation-query=SELECT 1
spring.datasource.druid.test-while-idle=true
spring.datasource.druid.test-on-borrow=false
spring.datasource.druid.test-on-return=false
spring.datasource.druid.pool-prepared-statements=true
spring.datasource.druid.max-pool-prepared-statement-per-connection-size=20
spring.datasource.druid.filters=stat,wall,slf4j
spring.datasource.driver-class-name=com.mysql.jdbc.Driver
spring.datasource.druid.url=jdbc:mysql://localhost:3306/crm_ssmdb?useUnicode=true&zeroDateTimeBehavior=convertToNull&allowMultiQueries=true&characterEncoding=UTF-8&serverTimezone=GMT%2B8
spring.datasource.druid.username=root
spring.datasource.druid.password=root

# 配置redis参数
spring.redis.port=6379
spring.redis.database=0
spring.redis.host=localhost
spring.redis.timeout=600s
spring.session.store-type=redis
# spring.cache.type=redis

# 测试Ehcache缓存
spring.cache.type=ehcache
spring.cache.ehcache.config=classpath:ehcache.xml

# 这里指定 redis的广播 和 cache的缓存key
spring.ext.cache.name=user
spring.ext.cache.redis.topic=cache
```

#### ehcache.xml

- 编写Ehcache的 缓存配置文件

  ```xml
  <ehcache>
      <!--
          磁盘存储:将缓存中暂时不使用的对象,转移到硬盘,类似于Windows系统的虚拟内存
          path:指定在硬盘上存储对象的路径
          path可以配置的目录有：
              user.home（用户的家目录）
              user.dir（用户当前的工作目录）
              java.io.tmpdir（默认的临时目录）
              ehcache.disk.store.dir（ehcache的配置目录）
              绝对路径（如：d:\\ehcache）
          查看路径方法：String tmpDir = System.getProperty("java.io.tmpdir");
       -->
      <diskStore path="java.io.tmpdir" />
      <!--
          defaultCache:默认的缓存配置信息,如果不加特殊说明,则所有对象按照此配置项处理
          maxElementsInMemory:设置了缓存的上限,最多存储多少个记录对象
          eternal:代表对象是否永不过期 (指定true则下面两项配置需为0无限期)
          timeToIdleSeconds:最大的发呆时间 /秒
          timeToLiveSeconds:最大的存活时间 /秒
          overflowToDisk:是否允许对象被写入到磁盘
          说明：下列配置自缓存建立起600秒(10分钟)有效 。
          在有效的600秒(10分钟)内，如果连续120秒(2分钟)未访问缓存，则缓存失效。
          就算有访问，也只会存活600秒。
       -->
      <defaultCache maxElementsInMemory="10000" eternal="false"
                    timeToIdleSeconds="300" timeToLiveSeconds="300" overflowToDisk="true" />
      <!-- cache就是具体的 缓存组。这里声明，然后@cacheable才可以使用 -->
      <cache name="myCache" maxElementsInMemory="10000" eternal="false"
             timeToLiveSeconds="60" overflowToDisk="true" />
      <cache name="user" maxElementsInMemory="10000" eternal="false"
             timeToLiveSeconds="60" overflowToDisk="true" />
      <cache name="school" maxElementsInMemory="10000" eternal="false"
             timeToLiveSeconds="60" overflowToDisk="true" />
  </ehcache>
  ```

#### 重点！编写Config文件

- 具体的二级缓存实现都写在 Config 配置文件中

  ```java
  @Configuration
  @ConditionalOnWebApplication
  public class TwoCacheConfig {
      // 进行二级缓存的处理，进行分布式锁创建

      // redis广播地址
      @Value("${spring.ext.cache.redis.topic}")
      private String topic;

      @Value("${spring.ext.cache.name}")
      private String ehcacheName;

      @Autowired
      private RedisTemplate redisTemplate;

      // 创建返回 Ehcache 的Bean
      @Bean
      public EhCacheCacheManager ehCacheCacheManager() {
          return new EhCacheCacheManager(EhCacheManagerUtils.buildCacheManager());
      }

      @Bean
      @Primary
      public RedisCacheManager twoRedisCacheManager() {
          RedisCacheWriter writer = RedisCacheWriter.lockingRedisCacheWriter(redisTemplate.getConnectionFactory());
          return new TwoRedisCacheManager(writer , getRedisCacheConfigurationWithTtl(60) , redisTemplate);
      }

      // redis消息监听器，用来进行 sub接收广播消息
      @Bean
      public RedisMessageListenerContainer redisMessageListenerContainer(RedisConnectionFactory redisConnectionFactory,
                                                                         MessageListenerAdapter messageListenerAdapter) {
          RedisMessageListenerContainer container = new RedisMessageListenerContainer();
          container.setConnectionFactory(redisConnectionFactory);
          container.addMessageListener(messageListenerAdapter , new PatternTopic(topic));
          return container;
      }

      // redis的 监听消息适配器，用来处理 消息的业务方法 , 绑定消息处理器，利用反射技术调用消息处理器的业务方法
      @Bean
      public MessageListenerAdapter messageListenerAdapter(RedisCacheManager twoRedisCacheManager) {
          // 引入RedisCacheManager 的 cache控制类
          // 之前在RedisCacheManager中通过 publishMessage 进行发送通知 到 分布式的 各个JVM中进行处理，Ehcache的缓存清理
          System.out.println("处理Ehcache缓存的消息适配器注册了");
          return new MessageListenerAdapter(new MessageListener() {
              @Override
              public void onMessage(Message message, byte[] bytes) {
                  // 在这里可以直接获取 redis 广播时传递的参数
                  // 调用 redisCachemanager 进行处理 本地Ehcache缓存
                  try {
                      // 在这里解析数据时出了问题，syntax error, expect {, actual error, pos 0, fastjson-version 1.2.49
                      // 格式出现 �� t ){"cacheName":"user","key":"1","type":"1"} 前面有个 错误编码，不知道咋回事!
                      UpdateCache updateCache = JSON.parseObject(new String(message.getBody()).split("\\)")[1], UpdateCache.class);
                      System.out.println(updateCache);
                      CustomCache cache = (CustomCache)twoRedisCacheManager.getCache(updateCache.getCacheName());
                      if (cache != null) {
                          // 调用方法进行处理
                          cache.clearLocal(updateCache);
                      }
                  } catch (Exception e) {
                      e.printStackTrace();
                  }
              }
          });
      }


      // 配置 key 的声明周期 过期时间
      private RedisCacheConfiguration getRedisCacheConfigurationWithTtl(Integer seconds) {
          Jackson2JsonRedisSerializer<Object> jackson2JsonRedisSerializer = new Jackson2JsonRedisSerializer<>(Object.class);
          ObjectMapper om = new ObjectMapper();
          om.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
          om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
          jackson2JsonRedisSerializer.setObjectMapper(om);
          RedisCacheConfiguration redisCacheConfiguration = RedisCacheConfiguration.defaultCacheConfig();
          redisCacheConfiguration = redisCacheConfiguration.serializeValuesWith( // serializeValuesWith设置存储的信息不乱吗
                  RedisSerializationContext
                          .SerializationPair
                          .fromSerializer(jackson2JsonRedisSerializer)
          ).entryTtl(Duration.ofSeconds(seconds)); // Duration. 的方法可以设置 声明周期存活时间的单位，秒..分..

          return redisCacheConfiguration;
      }


      // 重写一个 CacheManager 的Bean构造方法 ， 由Cachemanager 中引出 cache的创造 , 这个CacheManager会被Bean注册
      // 所以关于 redis广播 进行缓存操作的方法 可以写在其中
      public class TwoRedisCacheManager extends RedisCacheManager {
          private RedisTemplate redisTemplate;

          @Autowired
          private EhCacheCacheManager ehCacheCacheManager;

          // 重写父类RedisCacheManager 的构造方法 ， 要接收一下 redisTemplate
          public TwoRedisCacheManager(RedisCacheWriter cacheWriter, RedisCacheConfiguration defaultCacheConfiguration, RedisTemplate redisTemplate) {
              super(cacheWriter, defaultCacheConfiguration);
              this.redisTemplate = redisTemplate;
          }

          // getCahce不需要重写，父方法直接可以使用，他会调用decorateCache装饰cache的方法，来处理cache，而我们重写了decorateCache
          @Override
          public Cache getCache(String name) {
              System.out.println("getCache获取缓存操作类");
              return super.getCache(name);
          }

          // 重写装饰 cache 缓存方法 , 这个返回的 cache 就是以后用作 缓存  存，取，清的类
          @Override
          protected Cache decorateCache(Cache cache) {
              // 通过 ehcacheName 获取缓存对象cache
              // 可以通过 EhcacheManager 来构造
  //            net.sf.ehcache.CacheManager ehcacheManager = net.sf.ehcache.CacheManager.create(this.getClass().getClassLoader().getResource("ehcache.xml"));
  //            net.sf.ehcache.Cache ehcacheXMl = ehcacheManager.getCache(cache.getName());
  //            EhCacheCache ehCacheCache = new EhCacheCache(ehcacheXMl);

              // 可以通过 之前Bean 注册的方法，然后这里引入
              Cache ehcache = ehCacheCacheManager.getCache(cache.getName());
              return new CustomCache(this,(RedisCache)cache , (EhCacheCache)ehcache);
          }

          // 发送广播通知，让各个JVM清除自己的 Ehcache缓存
          public void publishMessage(UpdateCache updateMessage) {
              System.out.println(JSON.toJSONString(updateMessage));
              this.redisTemplate.convertAndSend(topic, JSON.toJSONString(updateMessage));
          }

          // 接受一个消息清空本地缓存
          public void receiver(String json) {
              UpdateCache updateMessage = JSON.parseObject(json, UpdateCache.class);
              CustomCache cache = ((CustomCache) this.getCache(updateMessage.getCacheName()));
              if(cache!=null){
                  cache.clearLocal(updateMessage);
              }
          }

      }

      // 构造一个自定义的 cache 缓存操作类 , 需要继承 Cache 接口，重写里面方法
      // AbstractValueAdaptingCache 抽象类 实现了 Cahce总接口 。 具体区别是
      // 抽象类中有一个lookup方法，来集中获取缓存数据，而其他的 get 等方法 都来调用它。
      // 多了一个控制NullValue的包装处理 保存的value为null时，如果allowNullValues=true，则保存NullValue，如果allowNullValues=false，则抛出异常。默认为true
      public class CustomCache extends AbstractValueAdaptingCache {

          TwoRedisCacheManager twoRedisCacheManager;
          RedisCache redisCache;
          EhCacheCache ehCacheCache;

          public CustomCache(TwoRedisCacheManager twoRedisCacheManager , RedisCache redisCache, EhCacheCache ehCacheCache) {
              // super 选择是否保留 空值null
              // 保存的value为null时，如果allowNullValues=true，则保存NullValue，如果allowNullValues=false，则抛出异常。默认为true
              super(true);
              this.twoRedisCacheManager = twoRedisCacheManager;
              this.redisCache = redisCache;
              this.ehCacheCache = ehCacheCache;
          }

          // AbstractValueAdaptingCache比 Cache接口的区别在于 抽象类都是通过lookup来获取缓存数据，但是我都重写了其他的方法，所以这个不需要在写了
          @Override
          protected Object lookup(Object key) {
              return null;
          }

          @Override
          public String getName() {
              return redisCache.getName();
          }

          @Override
          public Object getNativeCache() {
              return redisCache.getNativeCache();
          }

          @Override
          public ValueWrapper get(Object key) {
              // 先获取 Ehcache的
              ValueWrapper valueWrapper = ehCacheCache.get(key);
              if (valueWrapper != null) {
                  System.out.println("获取的一级Ehcache缓存");
                  return valueWrapper;
              }else{
                  // 二级获取
                  ValueWrapper redisValue = redisCache.get(key);
                  System.out.println("获取的二级redis缓存");
                  if (redisValue != null) {
                      System.out.println("更新一级Ehcache缓存");
                      // 更新一下一级缓存 ， 这里进行存储，并不会更新其他JVM虚拟机的缓存，只对当前JVM有效
                      ehCacheCache.put(key, redisValue);
                  }
                  return redisValue;
              }
          }

          @Override
          public <T> T get(Object key, Class<T> type) {
              // 先获取 Ehcache的
              T valueWrapper = ehCacheCache.get(key , type);
              if (valueWrapper != null) {
                  return valueWrapper;
              }else{
                  // 二级获取
                  T redisValue = redisCache.get(key,type);
                  if (redisValue != null) {
                      // 更新一下一级缓存
                      ehCacheCache.put(key, redisValue);
                  }
                  return redisValue;
              }
          }

          @Override
          public <T> T get(Object key, Callable<T> valueLoader) {
              // 先获取 Ehcache的
              T valueWrapper = ehCacheCache.get(key , valueLoader);
              if (valueWrapper != null) {
                  return valueWrapper;
              }else{
                  // 二级获取
                  T redisValue = redisCache.get(key,valueLoader);
                  if (redisValue != null) {
                      // 更新一下一级缓存
                      ehCacheCache.put(key, redisValue);
                  }
                  return redisValue;
              }
          }

          @Override
          public void put(Object key, Object value) {
              System.out.println("存储113");
              System.out.println(ehCacheCache.getName());
              // 因为分布式缓存，每个JVM上都有一份 Ehcache缓存，就需要将其他 JVM也同步下 ， 将之前的key清理掉
              // 要先清理，避免当前JVM虚拟机，存一份然后又清理掉
              clearOtherJVM("1",key);
              // redis 和 Ehcache 都存储一份
              redisCache.put(key,value);
              ehCacheCache.put(key,value);
          }

          @Override
          public void evict(Object key) {
              // evict是清除单个 key
              redisCache.evict(key);
              ehCacheCache.evict(key);
              clearOtherJVM("1",key);
          }

          @Override
          public void clear() {
              // 清除所有
              redisCache.clear();
              ehCacheCache.clear();
              clearOtherJVM("0",null);
          }

          // 当分布式其他JVM接收到广播时，清理ehcache缓存 , 给redis接收广播时调用
          public void clearLocal(UpdateCache updateCache){
              System.out.println("JVM清理本地Ehcache缓存");
              if (updateCache.getType().equals("1")) {
                  // 清除单个缓存
                  ehCacheCache.evict(updateCache.getKey());
              } else {
                  // 清理全部缓存
                  ehCacheCache.clear();
              }
          }

          // 清除其他 JVM上的EHcache缓存
          public void clearOtherJVM(String type , Object key){
              UpdateCache updateCache = new UpdateCache(key, type, redisCache.getName());
              // 因为RedisCacheManager中引入有 redisTemplate 通过它来发送广播通知
              twoRedisCacheManager.publishMessage(updateCache);
          }
      }

      @Data
      @ToString
      public class UpdateCache implements Serializable {
          // 定义一个类，用作分布式时，清除其他JVM上的 Ehcache缓存时 所传递数据
          private Object key;
          // type 0为全部清除， 1 为清除某个key
          private String type;
          private String cacheName;

          public UpdateCache(Object key, String type, String cacheName) {
              this.key = key;
              this.type = type;
              this.cacheName = cacheName;
          }

          @Override
          public String toString() {
              return "UpdateCache{" +
                      "key=" + key +
                      ", type='" + type + '\'' +
                      ", cacheName='" + cacheName + '\'' +
                      '}';
          }
      }
  }
  ```

#### 具体调用测试

- 编写一个 Dao 方法类模拟查询数据库，进行缓存操作

  ```
  // user实体类中 只有一个 id ， username 两个属性，就不写了

  @Component
  public class UserDao {

      private static Map<String, User> map = new HashMap<String,User>();

      @PostConstruct
      public static void run() {
          map.put("1",new User("1","123"));
          map.put("2",new User("2","456"));
      }

      @Cacheable(cacheNames = "user",key = "#id")
      public User getUser(String id) {
          System.out.println("查询数据库111111-----------");
          return map.get(id);
      }

      // 清理缓存
      @CacheEvict(cacheNames = "user",key = "#id")
      public void evictUser(String id) {
          System.out.println("清理缓存id");
      }

  //    @Cacheable(value = "user",key = "#id")
  //    public User getUser2(String id) {
  //        System.out.println("查询数据库22222-----------");
  //        return map.get(id);
  //    }
  //
  //    @CachePut(value = "user",key = "#user.id")
  //    public void set(User user) {
  //        System.out.println("数据库操作3333333-----------");
  //        map.put(user.getId(),user);
  //    }

  }
  ```
- Test进行调用测试

  ```
  @RunWith(SpringJUnit4ClassRunner.class)
  @SpringBootTest(classes = {com.test.Boot.class})
  public class Test {
      @Autowired
      private UserDao userDao;

      @Autowired
      private RedisCacheManager redisCacheManager;

      @Autowired
      private EhCacheCacheManager ehCacheCacheManager;

      @Autowired
      private CacheManager cacheManager;

      // 二级缓存获取测试
      @org.junit.Test
      public void cache() throws InterruptedException {
          // 分布式 二级缓存测试
          System.out.println("第一次：" + userDao.getUser("1"));
          System.out.println("第二次：" + userDao.getUser("1"));

          Thread.sleep(65000);
          // redis中的声明周期已经过了，但是Ehcache中会有缓存
          System.out.println("第三次：" + userDao.getUser("1"));

          // 这里返回的cache 是原生的，并不是我们自己的 生成的
          TwoCacheConfig.CustomCache cache = (TwoCacheConfig.CustomCache) redisCacheManager.getCache("user");
          Cache.ValueWrapper valueWrapper = cache.get("1");
          System.out.println("最后一次：" + (User)valueWrapper.get());
      }

      // 二级缓存 清理缓存测试
      @org.junit.Test
      public void cache2() throws InterruptedException {
          // 存储一个缓存，然后 60秒内进行清理
          System.out.println("第一次：" + userDao.getUser("1"));

          Thread.sleep(2000);
          // 清理缓存
          userDao.evictUser("1");
          Cache cache = redisCacheManager.getCache("user");
          System.out.println(cache.get("1"));
      }

      @org.junit.Test
      public void cache5(){
          Cache cache = redisCacheManager.getCache("school");
          cache.put("1","123");
          // 查看一下 Ehcache上是否有 缓存数据
          System.out.println("Ehcache：" + ehCacheCacheManager.getCache("school"));
      }

      @org.junit.Test
      public void cache6(){
          // 这个是单独的 Ehcache 的缓存方法了，跟自定义的二级缓存无关
          // 通过构造方法引入，不需要再通过 config配置文件来 注册Bean
          net.sf.ehcache.CacheManager cacheManager = net.sf.ehcache.CacheManager.create(this.getClass().getClassLoader().getResource("ehcache.xml"));
          net.sf.ehcache.Cache cache = cacheManager.getCache("user");
          System.out.println(cache.get("1"));

  //        System.out.println("Ehcache：" + ehCacheCacheManager.getCache("user"));
  //        Cache cache = ehCacheCacheManager.getCache("user");
  //        System.out.println(cache.get("1"));
      }
  }
  ```
