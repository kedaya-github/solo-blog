title: SQL优化
date: '2020-10-08 19:14:04'
updated: '2020-10-08 19:14:04'
tags: [java, sql]
permalink: /articles/2020/10/08/1602155644120.html
---
![](https://b3logfile.com/bing/20180801.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# SQL优化

* mysql是一个 B/S架构。 分为客户端和服务端。
* mysql逻辑分层 ：
  ![20](file://M:/%E5%AD%A6%E4%B9%A0%E5%A5%97%E8%B7%AF2==/MD%E7%AC%94%E8%AE%B0/java%E5%9F%BA%E7%A1%80%E5%8A%A0%E5%BC%BA/assets/20.png?lastModify=1602155612)
* InnoDB ： 事务优先，防止并发问题，行锁
* MyISAM ： 性能优先 ， 表锁
* sql性能比较低， 执行时间太长。等待时间太长。sql语句不好连接查询，索引失效等。

## 优化索引

* 索引相当于 书的目录。
* 索引 index 是帮助mysql高效获取数据的 数据结构（数）。
* mysql索引 使用的数据结构 是 B树。

### 索引的弊端：

```
- 索引本身的空间很大。一般存在硬盘中。

- 索引不是所有情况都使用。1.数据量小的。 2.数据经常改变。 3.很少使用的字段。

- 索引提高查询的效率，但是降低 增删改的效率。
```

### 索引的优势：

```
- 提高查询效率

- 降低cpu的使用率，因为 B树 索引本身就是一个 排过序的索引。
```

### 什么样的字段适合创建索引

```
1. 经常作为查询条件的列上，加快所有的速度
2. id主键上，添加主键就会自动创建索引
3. 经常需要排序的列上创建
4. 在where条件 的字段上。 都要创建索引
```

### 索引优化

* 当你修改表字段数据时， 那么也会修改索引中的信息。
* 导致增删改，效率比较低。

## mysql中的索引种类

### B-Tree索引

![21](file://M:/%E5%AD%A6%E4%B9%A0%E5%A5%97%E8%B7%AF2==/MD%E7%AC%94%E8%AE%B0/java%E5%9F%BA%E7%A1%80%E5%8A%A0%E5%BC%BA/assets/21.png?lastModify=1602155612)

### Full-text索引

* Full-text索引 就是 全文索引。 存储结构也是b-tree。
* 主要我了解决 需要用like查询的低效问题。

### 索引创建

* 分类
  * 单值索引 ： 单列，age。 一个表可以有多个单值索引
  * 唯一索引 ： 不能重复。 id
  * 符合索引 ： 多个列构成。
* 创建索引：
  ```
  //方式一
  create 索引类型 索引名 on 表（字段）

  单值索引：
  create index ...
  唯一索引：
  create unique index ...
  复合索引：
  create index dept_name_index on tb（dept,name）; 设置多个字段。有前后顺序

  //方式二
  alter table 表名 索引类型 索引名(字段)

  //删除索引
  drop index 索引名 on 表名;

  //查询索引
  show idnex from 表名;
  ```

---

## SQL常见优化策略

```
避免全表扫描 ， 在where设计的列上建立索引
select * from tb where name != ''

避免判断null值 ， null不会进入索引的树，不会有索引效果
select id from tb where num is null

避免不等值判断
避免在where中不要使用 != 或 <> 操作符

避免使用 or 关键字

避免使用select *
```

---

## SQL性能问题

### sql的执行计划 explain

* 可以模拟sql优化器，执行sql语句。让开发人员知道sql语句，最后的执行状态。
* 查看执行计划： explain +SQL语句。
  explain select * from tb;

#### id属性

* explain 查询出执行计划后，进行解析：
  ![22](file://M:/%E5%AD%A6%E4%B9%A0%E5%A5%97%E8%B7%AF2==/MD%E7%AC%94%E8%AE%B0/java%E5%9F%BA%E7%A1%80%E5%8A%A0%E5%BC%BA/assets/22.png?lastModify=1602155612)

  ```
  id ： 相同，从上往下顺序执行
  多表连接查询，表的执行顺序，因为数量的格式改变而改变的原因。：笛卡尔积
  数据量小的表，优先查询。
  ```


  ![23](file://M:/%E5%AD%A6%E4%B9%A0%E5%A5%97%E8%B7%AF2==/MD%E7%AC%94%E8%AE%B0/java%E5%9F%BA%E7%A1%80%E5%8A%A0%E5%BC%BA/assets/23.png?lastModify=1602155612)

  ```
  子连接查询，先查最内层，在查最外层。所以id值会改变。
  id值越大，越先执行。
  ```

#### select_type属性

* PRIMARY ： 包含子查询SQL中的 主查询（最外层）；
* SUBQUERY ： 包含子查询 sql 中的 子查询（非最外层）

---

---

---

### 存储引擎管理命令

```
查看数据库支持的存储引擎
show engines

查看数据库当前使用引擎
show variables like '%storage_engine%'

查看数据表使用的存储引擎
show create table table_name

创建表指定存储引擎
create table table_name (...) engine = engine_name

修改表的存储引擎
alter table table_name engine = engine_name

修改默认的存储引擎
在mysql配置文件 ： default-storage-engine=INNODB
/my.ini文件
```

---

# 锁
